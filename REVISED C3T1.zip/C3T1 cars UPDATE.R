install.packages("readr")
library(readr) 
cars.csv<- read.csv("C:\\Users\\Alma Mtz\\OneDrive\\Documents\\cars.csv")
#List your attributes within your data set
attributes(cars.csv)
#Prints the min, max, mean, median, and quartiles of each attribute.
summary(cars.csv)
#Displays the structure of your data set.
str(cars.csv)
#Names your attributes within your data set.
names(cars.csv) 
#Will print out the instances within that particular column in your data set.
cars.csv$speed.of.car
cars.csv$distance.of.car
#Histogram
hist(cars.csv$speed.of.car)
hist(cars.csv$distance.of.car)
#scatter plot
plot(cars.csv$speed.of.car,cars.csv$distance.of.car)
#Normal quantile plot
qqnorm(cars.csv$speed.of.car)
qqnorm(cars.csv$distance.of.car)
names(cars.csv)<-c("name","speed","distance") 
#Will count how many NA’s you have.
summary(cars.csv) 
#Will show your NA’s through logical data. (TRUE if it’s missing, FALSE if it’s not.)
is.na(cars.csv)
set.seed(123)
trainSize<-round(nrow(cars.csv)*0.7) 
testSize<-nrow(cars.csv)-trainSize
trainSize
testSize
training_indices<-sample(seq_len(nrow(cars.csv)),size =trainSize)
trainSet<-cars.csv[training_indices,]
testSet<-cars.csv[-training_indices,] 
model1<-lm(distance~ speed, trainSet)
summary(model1)
PredictionsName <- predict(model1,testSet)
PredictionsName
