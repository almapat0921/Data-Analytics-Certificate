install.packages("readr")
library("readr")
iris.csv <- read.csv("C:\\Users\\Alma Mtz\\OneDrive\\Documents\\iris.csv")
attributes(iris.csv)
summary(iris.csv) 
str(iris.csv)
names(iris.csv)
hist(iris.csv$Sepal.Length)
hist(iris.csv$Sepal.Width)
hist(iris.csv$Petal.Length)
hist(iris.csv$Petal.Width)
plot(iris.csv$Sepal.Length)
plot(iris.csv$Sepal.Width)
plot(iris.csv$Petal.Length)
plot(iris.csv$Petal.Width)
qqnorm(iris.csv)
iris.csv$Species<- as.numeric(iris.csv$Species)
#Drops any rows with missing values, but keeps track of where they were.
na.exclude(iris.csv$Species)
iris.csv$Species<- as.numeric(iris.csv$Species)
set.seed(123)
trainSize <- round(nrow(iris.csv) * 0.2)
testSize <- nrow(iris.csv) - trainSet
trainSize
testSize
trainSet <- iris.csv[training_indices, ]
testSet <- iris.csv[-training_indices, ]
set.seed(405)
trainSet <- iris.csv[training_indices, ]
testSet <- iris.csv[-training_indices, ]
LinearModel<- lm(Petal.Width~ Petal.Length, trainSet)
summary(LinearModel)
prediction<-predict(LinearModel)
prediction
